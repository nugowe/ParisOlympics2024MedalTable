from django.apps import AppConfig


class MedaltableAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'medaltable_app'
